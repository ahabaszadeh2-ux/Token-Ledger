const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  loadData: () => ipcRenderer.invoke('load-data'),
  saveData: (entries) => ipcRenderer.invoke('save-data', entries),
  getStoragePath: () => ipcRenderer.invoke('get-storage-path'),
  chooseFolder: () => ipcRenderer.invoke('choose-folder'),
  getCredentials: () => ipcRenderer.invoke('get-credentials'),
  saveCredentials: (creds) => ipcRenderer.invoke('save-credentials', creds),
  onStoragePathUpdated: (callback) => {
    ipcRenderer.on('storage-path-updated', (event, newPath) => callback(newPath));
  },
});
