const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

let win;

const CONFIG_PATH = path.join(app.getPath('userData'), 'config.json');
const DEFAULT_DATA_FILENAME = 'token-ledger-data.json';

function loadConfig() {
  try {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch (e) {
    return {};
  }
}

function saveConfig(cfg) {
  try {
    fs.mkdirSync(path.dirname(CONFIG_PATH), { recursive: true });
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2), 'utf-8');
  } catch (e) {
    console.error('Failed to save config', e);
  }
}

function getStorageFilePath() {
  const cfg = loadConfig();
  if (cfg.storageDir) {
    return path.join(cfg.storageDir, DEFAULT_DATA_FILENAME);
  }
  return path.join(app.getPath('userData'), DEFAULT_DATA_FILENAME);
}

function createWindow() {
  win = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 900,
    minHeight: 600,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

ipcMain.handle('load-data', async () => {
  try {
    const filePath = getStorageFilePath();
    const raw = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch (e) {
    return [];
  }
});

ipcMain.handle('save-data', async (event, entries) => {
  try {
    const filePath = getStorageFilePath();
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, JSON.stringify(entries, null, 2), 'utf-8');
    return true;
  } catch (e) {
    console.error('Failed to save data', e);
    return false;
  }
});

ipcMain.handle('get-storage-path', async () => {
  return getStorageFilePath();
});

ipcMain.handle('get-credentials', async () => {
  const cfg = loadConfig();
  if (cfg.authUsername && cfg.authPassword) {
    return { username: cfg.authUsername, password: cfg.authPassword };
  }
  return null;
});

ipcMain.handle('save-credentials', async (event, creds) => {
  try {
    const cfg = loadConfig();
    cfg.authUsername = creds.username;
    cfg.authPassword = creds.password;
    saveConfig(cfg);
    return true;
  } catch (e) {
    console.error('Failed to save credentials', e);
    return false;
  }
});

ipcMain.handle('choose-folder', async () => {
  const result = await dialog.showOpenDialog(win, {
    properties: ['openDirectory'],
    title: 'انتخاب پوشه ذخیره‌سازی',
  });
  if (result.canceled || !result.filePaths[0]) {
    return { changed: false };
  }
  const newDir = result.filePaths[0];
  const oldPath = getStorageFilePath();

  const cfg = loadConfig();
  cfg.storageDir = newDir;
  saveConfig(cfg);

  const newPath = getStorageFilePath();

  try {
    if (fs.existsSync(oldPath) && !fs.existsSync(newPath)) {
      fs.copyFileSync(oldPath, newPath);
    }
  } catch (e) {
    console.error('Failed to migrate data file', e);
  }

  if (win) {
    win.webContents.send('storage-path-updated', newPath);
  }

  return { changed: true, path: newPath };
});
